读出（read-aloud）句子范式 — 最小运行包
==========================================

1. 安装依赖（Python 3.10+）:
   pip install -r requirements.txt

2. 从本目录（read_aloud_paradigm/）的根目录运行，例如:
   python scripts/run_read_aloud.py --sentences stimuli/large_corpus_1800_372/20260709_152839_review_74rows_sentences-1.txt --no-pre-audio --no-post-audio --output-prefix large_corpus_372

   语料已拆分为 -1 / -2 / -3 三个分片，按需替换文件名。
   可选参数: --font-size（默认100）、--progress-style {segmented,continuous}、
   --no-cue-tone（关闭绿方块同步提示音）等，详见 --help。

3. 结果自动写入 timestamp/（自动创建）: large_corpus_372_<时间戳>.csv/.json

默认时序: 红方块 2.0±0.2s -> 绿方块+提示音 -> 每字 1.2s(1.0 填充 + 0.2 停顿)
          -> 末字保持 0.5s -> 立即下一句（无间隔、无十字）
文字居中于上半屏中央，100px 方块居中于屏幕正中央。
字体使用系统字体（Windows: 微软雅黑/黑体/宋本），无需附带字体文件。
退出: ESC 或鼠标点击。
